package com.ict03.class01;

public class Ex14_main {
	public static void main(String[] args) {
		Ex14 t1 = new Ex14();
		
		System.out.println(t1.su1);
		System.out.println(Ex14.su2);
		System.out.println();
		
		Ex14 t2 = new Ex14();

		System.out.println(t2.su1);
		System.out.println(Ex14.su2);
		System.out.println();
		
		Ex14 t3 = new Ex14();
		
		System.out.println(t3.su1);
		System.out.println(Ex14.su2);
		System.out.println();
	}
}
