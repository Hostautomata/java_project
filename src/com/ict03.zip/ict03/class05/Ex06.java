package com.ict03.class05;

interface Ex06 {
	void add(int s1, int s2);
	void sub(int s1, int s2);
	void mul(int s1, int s2);
	void div(int s1, int s2);
	
	
}
