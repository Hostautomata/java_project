package com.ict03.class05;

public class E07 implements Ex06 {

	@Override
	public void add(int s1, int s2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sub(int s1, int s2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mul(int s1, int s2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void div(int s1, int s2) {
		// TODO Auto-generated method stub
		
	}
	
}
