package com.ict03.class05;

interface Ex08 {
	void plus(int s1, int s2);
}
interface Ex09 {
	void minus(int s1, int s2);
}
interface Ex10 {
	void multiplication(int s1, int s2);
}