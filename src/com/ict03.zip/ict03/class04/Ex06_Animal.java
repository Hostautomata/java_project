package com.ict03.class04;

public abstract class Ex06_Animal {
	public abstract void sound() ;
	public abstract void eat(String food) ;
	public abstract String play() ;
}
