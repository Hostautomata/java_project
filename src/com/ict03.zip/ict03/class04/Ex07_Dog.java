package com.ict03.class04;

public class Ex07_Dog extends Ex06_Animal{
	
	@Override
	public void sound() {
		System.out.println("�۸�");
	}

	@Override
	public void eat(String food) {
		System.out.println("���ں�");
	}

	@Override
	public String play() {
		
		return "��å����";
	}

}
