package com.ict03.class07;
interface Remocon{
	void on();
	void off();
}
class Machine{
	Remocon tv = new Remocon() {
		
		@Override
		public void on() {
			System.out.println("tv�� �մϴ�.");
		}
		
		@Override
		public void off() {
			System.out.println("tv�� ���ϴ�.");
		}
	};
	Remocon radio = new Remocon() {
		
		@Override
		public void on() {
			System.out.println("������ �մϴ�.");
		}
		
		@Override
		public void off() {
			System.out.println("������ ���ϴ�.");
		}
	};
	
}

public class Ex06 {
	public static void main(String[] args) {
		Machine machine = new Machine();
		machine.tv.on();
		machine.tv.off();
		machine.radio.on();
		machine.radio.off();
	}
}
